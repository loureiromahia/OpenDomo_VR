This directory will contain any configuration files needed for commands.
