This directory contains all the modes. Modes simply mean that a
different dictionary is being used for recognition. This folder will
thus contain dictionaries and PNG files of the same name for the icon
to display when the mode is changed.
